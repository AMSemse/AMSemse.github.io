const nappi = document.getElementById("btn");
nappi.addEventListener("click", myFunction);

//let input;
//let ulTyped;

function myFunction() {
    input = document.getElementById("input").value;
    //ulTyped = document.getElementById("ulTyped");

    let ul = document.createElement("ul");
    ul.setAttribute("class", "list-group");

    document.getElementById("renderList").appendChild(ul);

    let li = document.createElement("li");
    li.setAttribute("class", "list-group-item");

    ul.appendChild(li);

    li.innerHTML = li.innerHTML + input;
};